using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class end : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
            GoToMenu();
    }

    public static void GoToMenu() 
    {
        Time.timeScale = 1f;

        SceneManager.LoadScene(0);
    }
}
