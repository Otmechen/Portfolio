using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class follow : MonoBehaviour
{
    
    public Vector3 dir;
    Vector3 rot;
    float rotfuerza = 10;
    public float speed;
    Rigidbody rb;

    private void Start()
    {
        dir = transform.forward;
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {

        speedcontrol();

    }

    private void FixedUpdate()
    {
        moveplayer();
    }

    private void moveplayer()
    {
        dir = transform.forward * speed;

        rb.AddForce(dir.normalized * speed , ForceMode.Force);
    }

    private void speedcontrol()
    {
        Vector3 flatvel = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        if (flatvel.magnitude > speed)
        {

            Vector3 limited = flatvel.normalized * speed;
            rb.velocity = new Vector3(limited.x, rb.velocity.y, limited.z);

        }

    }

}
