using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieManager : MonoBehaviour
{
    [SerializeField] float _viewRadius;
    public float ViewRadius { get { return _viewRadius * _viewRadius; } }

    public static ZombieManager Instance { get; private set; }

    public List<Zombie> AllZombies { get; private set; }

    void Awake()
    {
        Instance = this;

        AllZombies = new List<Zombie>();
    }

    public void RegisterNewZombie(Zombie newZombie)
    {
        if (!AllZombies.Contains(newZombie))
            AllZombies.Add(newZombie);
    }
}
