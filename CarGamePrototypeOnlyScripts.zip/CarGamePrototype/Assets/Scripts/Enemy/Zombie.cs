using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie : MonoBehaviour
{
    private Vector3 _velocity;

    public int _lifeZombie;

    public float maxSpeed;
    public float maxForce;

    Animator _anim;

    [SerializeField] CarController _pursuitTarget;

    private void Awake()
    {
        _anim = GetComponent<Animator>();
        _lifeZombie = 1;
    }

    private void Update()
    {
        if (Vector3.Distance(_pursuitTarget.transform.position, transform.position) <= ZombieManager.Instance.ViewRadius)
            AddForce(Pursuit());

        else
        {
            _velocity = new Vector3(0, 0, 0);
            _anim.SetBool("_isChasing", false);
            _anim.SetBool("_isIdle", true);
        }            

        transform.position += _velocity * Time.deltaTime;
        transform.forward = _velocity;
    }

    void AddForce(Vector3 force)
    {
        _velocity = Vector3.ClampMagnitude(_velocity + force, maxSpeed);
    }

    public void IDied()
    {
        if(_lifeZombie <= 0)
        {
            StartCoroutine(Death());
        }
    }

    IEnumerator Death()
    {
        _anim.SetBool("_isDead", true);
        _anim.SetBool("_isChasing", false);
        _anim.SetBool("_isIdle", false);
        yield return new WaitForSeconds(1.5f);
        Destroy(this.gameObject);
    }

    Vector3 Seek(Vector3 targetPos)
    {
        Vector3 desired = targetPos - transform.position;
        desired.Normalize();
        desired *= maxSpeed;

        Vector3 steering = desired - _velocity;
        steering = Vector3.ClampMagnitude(steering, maxForce);

        return steering;
    }

    Vector3 Pursuit()
    {
        Vector3 desired = Vector3.zero;

        Vector3 dirToPlayer = _pursuitTarget.transform.position - transform.position;

        Vector3 pos = _pursuitTarget.transform.position;

        if(dirToPlayer.sqrMagnitude <= ZombieManager.Instance.ViewRadius)
        {
            _anim.SetBool("_isChasing", true);
            _anim.SetBool("_isIdle", false);
            desired = Seek(pos);
        }
        else
        {
            _anim.SetBool("_isChasing", false);
            _anim.SetBool("_isIdle", true);
        }
        return desired;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            _lifeZombie--;
            IDied();
        }
    }
}
