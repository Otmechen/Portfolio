[System.Serializable]

public class PointsData
{
    public int _pointsScrap;

    public PointsData(Points points) 
    {
        _pointsScrap = points.ScrapTotal;
    }
}
