using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Pause : MonoBehaviour
{
    [SerializeField]
    private GameObject MenuPause;

    [SerializeField] private GameObject dynamicJoystick;

    public void OnPressPause()
    {
        Time.timeScale = 0f;

        MenuPause.SetActive(true);
        dynamicJoystick.SetActive(false);
    }

    public void OnPressResume()
    {
        Time.timeScale = 1f;

        MenuPause.SetActive(false);
        dynamicJoystick.SetActive(true);
    }
}
