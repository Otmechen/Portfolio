using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class FinishLine : MonoBehaviour
{
    [SerializeField] Timer currencyAlive;

    [SerializeField] GameObject PanelVictory;
    [SerializeField] GameObject dynamicJoystick;
    [SerializeField] GameObject pauseButton;
    [SerializeField] TextMeshProUGUI scrapGained;

    [SerializeField] Points points;

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Player")
        {
            PanelVictory.SetActive(true);
            dynamicJoystick.SetActive(false);
            pauseButton.SetActive(false);
            scrapGained.SetText("You gained " + currencyAlive.currency + " of scrap!");

            points.ScrapTotal += currencyAlive.currency;
        }
    }
}
