using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SetPoints : MonoBehaviour
{
    [SerializeField]
    private Text PointsStore;

    [SerializeField] Points points;

    private void Update()
    {        
        PointsStore.text = "Chatarra: " + points.ScrapTotal.ToString();
    }
}
