using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Points : MonoBehaviour
{
    public int ScrapTotal;

    public void SaveScrap()
    {
        SaveAndLoad.SaveScrap(this);
    }

    public void LoadScrap()
    {
        PointsData pointsData = SaveAndLoad.LoadScrap();
        ScrapTotal = pointsData._pointsScrap;
    }
}
