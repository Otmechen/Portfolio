using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
namespace Assets.Scripts.MenuScripts
{
    public class Menu : MonoBehaviour
    {
        public AudioMixer aud;
        public void lvl1()
        {
            SceneManager.LoadScene(1);
        }
        public void lvl2()
        {
            SceneManager.LoadScene(2);

        }
        public void lvl3()
        {
            SceneManager.LoadScene(3);

        }
        public void lvl4()
        {
            SceneManager.LoadScene(4);

        }
        public void lvl5()
        {

            SceneManager.LoadScene(5);
        }
        public void setvolume(float volume)
        {
            aud.SetFloat("volume", volume);
        }
    }
}