using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public static class SaveAndLoad
{
    public static void SaveScrap(Points _points)
    {
        PointsData pointsData = new PointsData(_points);
        string dataPath = Application.persistentDataPath + "/points.save";
        FileStream fileStream = new FileStream(dataPath, FileMode.Create);
        BinaryFormatter binaryFormatter = new BinaryFormatter();
        binaryFormatter.Serialize(fileStream, pointsData);
        fileStream.Close();
    }

    public static PointsData LoadScrap()
    {
        string dataPath = Application.persistentDataPath + "/points.save";

        if (File.Exists(dataPath))
        {
            FileStream fileStream = new FileStream(dataPath, FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            PointsData pointsData = (PointsData)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();
            return pointsData;
        }
        else return null;
    }
}
