using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerState : MonoBehaviour
{
    public static void Save(MonoBehaviour Component)
    {
        Debug.Log(JsonUtility.ToJson(Component));
        PlayerPrefs.SetString("Chatarra", JsonUtility.ToJson(Component));
    }

    public static void Load(MonoBehaviour Component)
    {
        JsonUtility.FromJsonOverwrite(PlayerPrefs.GetString("Chatarra"), Component);
    }
}
