using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    //private const string HORIZONTAL = "Horizontal";
    //private const string VERTICAL = "Vertical";

    private float horizontalInput;
    private float verticalInput;
    private float steerAngle;
    private float currentSteerAngle;
    private float currentBreakForce;
    private bool isBreaking = false;

    [SerializeField] private DynamicJoystick dynamicJoystick_;

    [SerializeField] public float motorForce;
    [SerializeField] private float breakForce;
    [SerializeField] private float maxSteeringAngle;

    [SerializeField] private WheelCollider frontLeftWhellCollider;
    [SerializeField] private WheelCollider frontRightWhellCollider;
    [SerializeField] private WheelCollider rearLeftWhellCollider;
    [SerializeField] private WheelCollider rearRightWhellCollider;
    public WheelCollider frontLeftWheel { get { return frontLeftWhellCollider; } }
    public WheelCollider frontRighttWheel { get { return frontRightWhellCollider; } }

    Vector3 _velocity;
    public Vector3 Velocity { get { return _velocity; } }

    [SerializeField] private Transform frontLeftWhellTransform;
    [SerializeField] private Transform frontRightWhellTransform;
    [SerializeField] private Transform rearLeftWhellTransform;
    [SerializeField] private Transform rearRightWhellTransform;

    private void FixedUpdate()
    {
        GetInput();
        HandleMotor();
        HandleSteering();
        UpdateWheels();

        _velocity = new Vector3(frontLeftWhellCollider.motorTorque, 0,frontLeftWhellCollider.motorTorque);
    }

    public void GetInput()
    {
        horizontalInput = dynamicJoystick_.Horizontal;
        verticalInput = dynamicJoystick_.Vertical;
        isBreaking = Input.GetKey(KeyCode.Space);
        print(isBreaking);
    }

    public void GetBreak()
    {
        isBreaking = true;
        Debug.Log("Freno de mano!" + isBreaking);
    }

    public void ReleaseBreak()
    {
        isBreaking = false;
        Debug.Log("Solto el freno de mano!" + isBreaking);
    }

    private void HandleMotor()
    {
        frontLeftWhellCollider.motorTorque = verticalInput * motorForce;
        frontRightWhellCollider.motorTorque = verticalInput * motorForce;
        currentBreakForce = isBreaking ? breakForce : 0f;
        if(isBreaking)
        {
            ApplyBreaking();
            Debug.Log("Se llama a el freno de mano!");
        }
    }

    private void ApplyBreaking()
    {
        frontRightWhellCollider.brakeTorque = currentBreakForce;
        frontLeftWhellCollider.brakeTorque = currentBreakForce;
        rearRightWhellCollider.brakeTorque = currentBreakForce;
        rearLeftWhellCollider.brakeTorque = currentBreakForce;

        Debug.Log("Se aplica el freno de mano!");
    }

    private void HandleSteering()
    {
        currentSteerAngle = maxSteeringAngle * horizontalInput;
        frontLeftWhellCollider.steerAngle = currentSteerAngle;
        frontRightWhellCollider.steerAngle = currentSteerAngle;
    }

    private void UpdateWheels()
    {
        UpdateSingleWheel(frontLeftWhellCollider, frontLeftWhellTransform);
        UpdateSingleWheel(frontRightWhellCollider, frontRightWhellTransform);
        UpdateSingleWheel(rearLeftWhellCollider, rearLeftWhellTransform);
        UpdateSingleWheel(rearRightWhellCollider, rearRightWhellTransform);
    }

    private void UpdateSingleWheel(WheelCollider whellCollider, Transform whellTransform)
    {
        Vector3 pos;
        Quaternion rot;
        whellCollider.GetWorldPose(out pos, out rot);
        whellTransform.position = pos;
        whellTransform.rotation = rot;
    }
}
