using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Estados : MonoBehaviour
{
    bool Changestate;

    Restart _carState;
    Speeds _speeds;
    CarController _carController;

    private float targetTime = 6f;

    [SerializeField] AudioSource _carRepair;
    public AudioSource breaksound;
    [SerializeField] AudioSource _turboSound;

    [SerializeField] GameObject _turboSmoke;    

    private void Start()
    {
        _carState = GetComponent<Restart>(); 
        _speeds = new Speeds();
        _carController = GetComponent<CarController>();
    }

    private void Update()
    {
        if (Changestate == true)
            StartCoroutine(timer());

        if (targetTime <= 0.0f)
        {
            Changestate = false;
            StopAllCoroutines();
            _speeds.NormalFuncion(_carController);
            _turboSmoke.SetActive(false);
            //_material.SetColor("_Color", new Color(255, 255, 255));
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == 8)
        {
            Changestate = true;
            if (other.CompareTag("Strong"))
            {
                _carState._carLife ++;
                _carRepair.Play();
                Destroy(other.gameObject);
            }
            if (other.CompareTag("faster"))
            {
                targetTime = 10f;
                _turboSound.Play();
                _speeds.Faster(_carController);
                _turboSmoke.SetActive(true);
                Destroy(other.gameObject);
                Debug.Log("Soy mas rapido");
            }
        }
    }

    IEnumerator timer()
    {
        if (targetTime > 0.0f)
            targetTime -= Time.deltaTime;
        else
           yield return null;
    }    
}

public class Speeds
{
    public void BrokeFuncion(CarController _carController)
    {
        _carController.motorForce = 0;
    }
    public void NormalFuncion(CarController _carController)
    {
        _carController.motorForce = 1000;
    }
    public void Faster(CarController car)
    {
        car.motorForce = 2000;
    }
}
