using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public enum controlmode { keyboard=1,touch=2}

public class Joystic : MonoBehaviour
{
    public controlmode control;
    public float steer;
    public GameObject UI;
    public Movement move;

    public CarController cC;

    public void steerinput(float input) 
    { 
        steer = input; 
    }

    private void Update()
    {
        //steer = Input.GetAxis("Horizontal");
        if (control==controlmode.keyboard)
        {            
            UI.SetActive(false);
        }
        else
        {
            UI.SetActive(true);
        }
    }

    private void FixedUpdate()
    {
        
    }

}
