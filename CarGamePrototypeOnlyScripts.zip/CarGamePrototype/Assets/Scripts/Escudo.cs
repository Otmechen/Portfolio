using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Escudo : MonoBehaviour
{
    [SerializeField] private GameObject shield;

    public int LifeShield;

    private void Start()
    {
        LifeShield = 3;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.layer == 6)
        {
            Destroy(other.gameObject);

            if (LifeShield <= 0)
                shield.SetActive(false);
            else
                LifeShield --;          
        }
    }
}
