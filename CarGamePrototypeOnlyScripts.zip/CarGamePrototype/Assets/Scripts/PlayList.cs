using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class PlayList : MonoBehaviour
{
    public AudioClip[] audioClips;
    private int currentAudio = -1;
    public AudioSource audioSource;

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        audioSource.loop = false;
        PlayNextRandomAudio();
    }

    private void Update()
    {
        if (!audioSource.isPlaying)
        {
            PlayNextRandomAudio();
        }
    }

    private void PlayNextRandomAudio()
    {
        int randomAudio;
        do
        {
            randomAudio = Random.Range(0, audioClips.Length);
        } while (randomAudio == currentAudio);

        currentAudio = randomAudio;
        audioSource.clip = audioClips[currentAudio];
        audioSource.Play();
    }
}
