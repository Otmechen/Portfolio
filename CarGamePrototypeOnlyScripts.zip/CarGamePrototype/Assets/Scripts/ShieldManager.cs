using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldManager : MonoBehaviour
{
    [SerializeField] GameObject shield;

    public static bool isPurchase;

    void Start()
    {
        shield.SetActive(isPurchase);
    }
}
