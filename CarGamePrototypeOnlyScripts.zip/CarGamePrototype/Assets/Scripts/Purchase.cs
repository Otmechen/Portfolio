using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Purchase : MonoBehaviour
{
    [SerializeField] Points points;

    public void PurchaseShield()
    {
        if (points.ScrapTotal >= 100 && !ShieldManager.isPurchase)
        {
            ShieldManager.isPurchase = true;
            points.ScrapTotal -= 100;
        }
    }
}
