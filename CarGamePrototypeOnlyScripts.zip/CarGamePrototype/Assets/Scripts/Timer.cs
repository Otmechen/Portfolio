using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    [SerializeField]
    private Text TimeDisplay;

    [SerializeField] Restart lifeCar;

    public float TimerAlive;
    public float timerTxt;

    public int currency;

    void Update()
    {
        if(lifeCar._carLife > 0)
            TimerAlive += Time.deltaTime;

        TimeDisplay.text = "" + ((int)TimerAlive).ToString();

        currency = 500 - (int)TimerAlive;
    }
}
