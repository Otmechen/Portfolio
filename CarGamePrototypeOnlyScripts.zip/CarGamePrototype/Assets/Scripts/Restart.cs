using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Restart : MonoBehaviour
{
    public int _carLife = 3;

    public AudioSource _aS;

    Zombie _zombie;
    Estados _states;
    CarController _carController;

    [SerializeField] GameObject PanelGameOver;
    [SerializeField] GameObject dynamicJoystick;
    [SerializeField] GameObject pauseButton;

    [SerializeField] Points points;

    private void Start()
    {
        _states = GetComponent<Estados>();
        _carController = GetComponent<CarController>();
    }

    private void Update()
    {
        if(_carLife <= 0)
            Invoke("loaded", 1);
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.layer==6)
        {
            if ( _carController.frontRighttWheel.motorTorque >= (_carController.motorForce % 45))
            {
                _aS.Play();
                Destroy(collision.gameObject);
                _carLife--;             
            }
            else
            {
                _aS.Play();
                _carLife--;
            }

            if (collision.gameObject.CompareTag("Zombie"))
            {
                _zombie = collision.gameObject.GetComponent<Zombie>();

                _aS.Play();
                _carLife--;

                _zombie._lifeZombie--;
                _zombie.IDied();
            }
        }
    }

    private void loaded()
    {
        points.ScrapTotal += 50;

        PanelGameOver.SetActive(true);
        dynamicJoystick.SetActive(false);        
        pauseButton.SetActive(false);
    }
}
