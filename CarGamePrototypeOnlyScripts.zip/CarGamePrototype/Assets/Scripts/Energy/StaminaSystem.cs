using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StaminaSystem : MonoBehaviour
{
    private int currentStamina;
    [SerializeField]
    private int maxStamina = 99;
    private string maxStaminaString;
    [SerializeField]
    private int secondsToRegainStamina;
    private DateTime currentDate;
    [SerializeField]
    private Text currentStaminaDisplay;
    [SerializeField]
    private Text timeToNextStaminaPointDisplay;
    [SerializeField]
    private Text timeToFullStaminaDisplay;
    private Coroutine recoveryCoroutine;
    private TimeSpan timeToFullStamina;

    private void Awake()
    {
        maxStaminaString = "/" + maxStamina.ToString();
        currentStamina = PlayerPrefs.GetInt("Stamina", 0);
        if(currentStamina > maxStamina)
        {
            currentStamina = maxStamina;
            UpdateCurrentStaminaDisplay();
            timeToNextStaminaPointDisplay.text = "Full";
            timeToFullStaminaDisplay.text = "Full";
        }
        else if (currentStamina < maxStamina)
        {
            UpdateCurrentStaminaDisplay();
            currentDate = DateTime.UtcNow;
            string savedLastPlayTime = PlayerPrefs.GetString("LastPlayTime", currentDate.ToString());
            DateTime lastPlayTime = DateTime.Parse(savedLastPlayTime);
            TimeSpan timeSpanSinceLastPlay = currentDate - lastPlayTime;
            double secondsSinceLastPlay = timeSpanSinceLastPlay.TotalSeconds;
            print(currentDate.ToString());
            print(lastPlayTime.ToString());
            print(secondsSinceLastPlay);
            double staminaGainedSinceLastPlay = secondsSinceLastPlay / secondsToRegainStamina;
            if(staminaGainedSinceLastPlay >= 1.0)
            {
                GainStamina((int)staminaGainedSinceLastPlay);
            }
            if(currentStamina < maxStamina)
            {
                if(recoveryCoroutine != null)
                {
                    StopCoroutine(recoveryCoroutine);
                }
                timeToFullStamina = TimeSpan.FromSeconds((maxStamina - currentStamina) * secondsToRegainStamina -(staminaGainedSinceLastPlay % 1) * secondsToRegainStamina);
                recoveryCoroutine = StartCoroutine(UpdateStaminaRecoveryTimes());
            }
        }
    }

    private void UpdateCurrentStaminaDisplay()
    {
        currentStaminaDisplay.text = currentStamina.ToString() + maxStaminaString;
    }

    private IEnumerator UpdateStaminaRecoveryTimes()
    {
        double secondsToNextRecharge;
        while (timeToFullStamina.TotalSeconds > 0)
        {
            secondsToNextRecharge = timeToFullStamina.TotalSeconds % secondsToRegainStamina;
            timeToNextStaminaPointDisplay.text = string.Format("(0:00):(1:00)", (int)secondsToNextRecharge / 60, secondsToRegainStamina);
            timeToFullStaminaDisplay.text = timeToFullStamina.ToString(@"hh\:mm\:ss");
            if((int)secondsToNextRecharge == 1)
            {
                GainStamina(1);
            }
            yield return new WaitForSeconds(1);
            timeToFullStamina = timeToFullStamina.Subtract(TimeSpan.FromSeconds(1));
        }

        timeToNextStaminaPointDisplay.text = "Full";
        timeToFullStaminaDisplay.text = "Full";
        recoveryCoroutine = null;    
    }

    public bool hasMaxStamina
    {
        get { return currentStamina == maxStamina; }
    }

    public void GainStamina(int amount)
    {
        currentStamina += amount;
        if(currentStamina > maxStamina)
        {
            currentStamina = maxStamina;
            if(recoveryCoroutine != null)
            {
                StopCoroutine(recoveryCoroutine);
                recoveryCoroutine = null;

                timeToNextStaminaPointDisplay.text = "Full";
                timeToFullStaminaDisplay.text = "Full";
            }
        }
        else
        {
            double leftoverSeconds = secondsToRegainStamina - timeToFullStamina.TotalSeconds % secondsToRegainStamina;
            timeToFullStamina = TimeSpan.FromSeconds((maxStamina - currentStamina) * secondsToRegainStamina - leftoverSeconds);
            if(recoveryCoroutine == null)
            {
                recoveryCoroutine = StartCoroutine(UpdateStaminaRecoveryTimes());
            }
        }
        UpdateCurrentStaminaDisplay();
        PlayerPrefs.SetInt("Stamina", currentStamina);
        print("Current stamina= " + currentStamina);
        currentDate = DateTime.UtcNow;
        PlayerPrefs.SetString("LastPlayTime", currentDate.ToString());
    }

    private void StopStaminaRecovery()
    {

    }

    public void ConsumeStamina(int amount)
    {
        if (HasStamina(amount))
        {
            currentStamina -= amount;
            UpdateCurrentStaminaDisplay();
            PlayerPrefs.SetInt("Stamina", currentStamina);
            currentDate = DateTime.UtcNow;
            PlayerPrefs.SetString("LastPlayTime", currentDate.ToString());
            double leftoverSeconds = secondsToRegainStamina - timeToFullStamina.TotalSeconds;
            timeToFullStamina = TimeSpan.FromSeconds((maxStamina - currentStamina));
            if(recoveryCoroutine == null)
            {
                recoveryCoroutine = StartCoroutine(UpdateStaminaRecoveryTimes());
            }
            //return true;
            SceneManager.LoadScene(1);
        }
        else
        {
            //return false;
        }
    }

    public bool HasStamina(int amount)
    {
        return currentStamina >= amount;
    }

    public void SaveDate()
    {
        currentDate = DateTime.UtcNow;
        PlayerPrefs.SetString("LastPlayTime", currentDate.ToString());
    }

    public void CompareDate()
    {
        currentDate = DateTime.UtcNow;
        string savedLastPlayTime = PlayerPrefs.GetString("LastPlayTime", currentDate.ToString());
        DateTime lastPlayTime = DateTime.Parse(savedLastPlayTime);
        TimeSpan timeSpanSinceLastPlay = currentDate - lastPlayTime;
        double secondsSinceLastPlay = timeSpanSinceLastPlay.TotalSeconds;
        print(currentDate.ToString());
        print(lastPlayTime.ToString());
        print(secondsSinceLastPlay);
    }

    private bool pauseTimeSet;
    private DateTime pauseTime;
    private DateTime unPauseTime;

    private void OnApplicationFocus(bool focus)
    {
        if (!focus)
        {
            pauseTime = DateTime.UtcNow;
            pauseTimeSet = true;
        }
        else if(pauseTimeSet)
        {
            unPauseTime = DateTime.UtcNow;
            TimeSpan timeSpanSinceLastPlay = unPauseTime - pauseTime;
            double secondsSinceLastPlay = timeSpanSinceLastPlay.TotalSeconds;
            double staminaGainedSinceLastPlay = secondsSinceLastPlay / secondsToRegainStamina;
            if(staminaGainedSinceLastPlay >= 1.0)
            {
                GainStamina((int)staminaGainedSinceLastPlay);
            }
            double leftoverSeconds = timeToFullStamina.TotalSeconds - secondsSinceLastPlay;
            timeToFullStamina = TimeSpan.FromSeconds(leftoverSeconds);
            pauseTimeSet = false;
        }
    }
}
