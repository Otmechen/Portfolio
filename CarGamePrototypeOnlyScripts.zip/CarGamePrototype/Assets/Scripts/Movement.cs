using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    protected Joystick control;
    public Vector3 dir;
    Vector3 rot;
    float rotfuerza=10;
    public float speed;
    Rigidbody rb;

    [SerializeField] private float contadorInicial;
    [SerializeField] private float multiplicador;
    private float contador;

    private void Start()
    {
        dir = transform.forward;
        rb = GetComponent<Rigidbody>();
    }
    private void Update()
    {

        speedcontrol();
        
    }



    private void FixedUpdate()
    {
        moveplayer();
    }

    private void moveplayer()
    {

        dir = transform.forward*speed ;

        rb.AddForce(dir.normalized * speed * 5f, ForceMode.Force);

        if(contador >= contadorInicial)
        {
            speed += (speed * multiplicador);
            contador = 0;
        }
    }
    private void speedcontrol()
    {
        Vector3 flatvel = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        if (flatvel.magnitude > speed)
        {          
            Vector3 limited = flatvel.normalized * speed;
            rb.velocity = new Vector3(limited.x, rb.velocity.y, limited.z);         
        }
        contador += Time.deltaTime;
    }

    public void Horizontal(float horizontal)
    {
        horizontal = horizontal * 1.5f;
        print(horizontal);
        rot = new Vector3(0, horizontal, 0);
        Quaternion rotation = Quaternion.Euler(rot * rotfuerza * Time.deltaTime);
        rb.MoveRotation(rb.rotation * rotation);
    }
}
