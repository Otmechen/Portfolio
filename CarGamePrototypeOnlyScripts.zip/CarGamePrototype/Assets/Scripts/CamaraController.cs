using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamaraController : MonoBehaviour
{
    public Transform target;
    private Vector3 offset;

    public Camera mainCamera;
    public float vibrationIntensity = 0.5f;
    public AudioSource audioSource;

    void Start()
    {
        offset = transform.position - target.position;
    }

    void LateUpdate()
    {
        Vector3 newposition = new Vector3(offset.x + target.position.x, offset.y + target.position.y, offset.z + target.position.z);
        transform.position = Vector3.Lerp(transform.position, newposition, 7 * Time.deltaTime);
    }
}
