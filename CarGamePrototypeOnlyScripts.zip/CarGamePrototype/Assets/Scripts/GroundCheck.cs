using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundCheck : MonoBehaviour
{
    float _timeToCall = 0f;

    bool _isGrounded;

    float _timeWithoutGrounded;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag(null))
        {
            _isGrounded = true;
            _timeWithoutGrounded = 0f;
            Debug.Log("Esta en el piso desde el enter");
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (!other.CompareTag(null))
        {
            _isGrounded = true;
            _timeWithoutGrounded = 0f;
            Debug.Log("Esta en el piso desde el stay");
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag(null))
        {
            _isGrounded = false;
            Debug.Log("No esta en el piso");
        }
    }

    IEnumerator CallVoid()
    {
        yield return new WaitForSeconds(2f);
        CarRestart();        
    }

    void CallCoroutine()
    {
        if (_isGrounded == false && _timeWithoutGrounded >= 2f)
            StartCoroutine(CallVoid());
        else if (_isGrounded == false)
            _timeWithoutGrounded += Time.deltaTime;            
    }

    private void Update()
    {
        CallCoroutine();

        if (_timeToCall > 0)
            _timeToCall -= Time.deltaTime;
    }

    void CarRestart() 
    {
        if(_timeToCall <= 0)
        {
            var CarPlayer = gameObject.GetComponentInParent<CarController>();

            CarPlayer.transform.position = new Vector3(CarPlayer.transform.position.x, CarPlayer.transform.position.y + 1, CarPlayer.transform.position.z);
            CarPlayer.transform.rotation = Quaternion.identity;

            _timeToCall = 10f;

            Debug.Log("Resetee mi posicion");
        }       
    }
}
