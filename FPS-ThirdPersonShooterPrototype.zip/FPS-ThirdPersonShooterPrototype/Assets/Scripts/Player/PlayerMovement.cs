using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    #region Components
    [Header("Components")]
    [SerializeField] Rigidbody _rigidbody;
    [SerializeField] BoxCollider _checkGround;
    [SerializeField] Animator _animController;
    [SerializeField] Camera _camera;
    #endregion

    #region Max Values
    [Header("Max Values")]
    [SerializeField] float _maxAccelerateMovement;
    [SerializeField] float _maxWalkSpeed;
    [SerializeField] float _maxBackwardsWalkSpeed;
    [SerializeField] float _maxStrafeWalkSpeed;
    [SerializeField] float _maxJumpForce;
    [SerializeField] float _rotationSpeed;
    #endregion

    #region Variable Values
    [Header("Variable Values")]
    [SerializeField] Vector3 _velocity;
    [SerializeField] float _minimumAccelerateMovement;
    [SerializeField] float _walkSpeed;
    [SerializeField] float _backwardsWalkSpeed;
    [SerializeField] float _strafeWalkSpeed;
    [SerializeField] float _jumpForce;
    [SerializeField] bool _isGrounded;
    [SerializeField] bool _isMoving;
    #endregion

    #region Inputs
    [Header("Inputs")]
    [SerializeField] float _verticalInput;
    [SerializeField] float _horizontalInput;
    [SerializeField] bool _isJumping = false;
    #endregion

    #region Player Step Climb
    [Header("Player Step Climb")]
    [SerializeField] GameObject _stepRayUpper;
    [SerializeField] GameObject _stepRayLower;
    [SerializeField] float _stepHeight = 0.3f;
    [SerializeField] float _stepSmooth = 0.1f;
    #endregion

    void Start()
    {
        GetComponents();
        SetStepRayUpper();   
    }

    void Update()
    {
        GetInput();
        SetVelocitys();
        SetMovement();
        SetAnimations();        
    }

    private void FixedUpdate()
    {
        MovePlayer();
    }

    void GetComponents() 
    {
        _checkGround = GetComponentInChildren<BoxCollider>();
        _rigidbody = GetComponent<Rigidbody>();
        _animController = GetComponent<Animator>();
        _camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
        _stepRayUpper = GameObject.FindGameObjectWithTag("StepRayUpper");
        _stepRayLower = GameObject.FindGameObjectWithTag("StepRayLower");
    }

    void GetInput()
    {
        _verticalInput = Input.GetAxis("Vertical");
        _horizontalInput = Input.GetAxis("Horizontal");
        _isJumping = Input.GetKey("space") ? true : false;
    }

    void SetStepRayUpper()
    {
        _stepRayUpper.transform.position = new Vector3(_stepRayUpper.transform.position.x, _stepHeight, _stepRayUpper.transform.position.z);
    }

    void SetVelocitys()
    {
        _walkSpeed = (_rigidbody.velocity.magnitude >= _maxWalkSpeed) ? _minimumAccelerateMovement : _maxAccelerateMovement;
        _backwardsWalkSpeed = (_rigidbody.velocity.magnitude >= _maxBackwardsWalkSpeed) ? _minimumAccelerateMovement : _maxAccelerateMovement;
        _strafeWalkSpeed = (_rigidbody.velocity.magnitude >= _maxStrafeWalkSpeed) ? _minimumAccelerateMovement : _maxAccelerateMovement;
        _jumpForce = (_isJumping) ? _maxJumpForce : 0f;
    }

    void SetAnimations()
    {
        _animController.SetFloat("Input Vertical", _verticalInput);
        _animController.SetFloat("Input Horizontal", _horizontalInput);
        _animController.SetFloat("Velocity", _rigidbody.velocity.magnitude);
        _animController.SetBool("Is Moving", _isMoving);

        _isMoving = (_verticalInput != 0 || _horizontalInput != 0) ? true : false;
    }

    #region Movement Player
    
    void SetMovement()
    {
        Vector3 camFlatFwd = Vector3.Scale(_camera.transform.forward, new Vector3(1, 0, 1)).normalized;
        Vector3 flatRight = new Vector3(_camera.transform.right.x, 0, _camera.transform.right.z).normalized;

        Vector3 m_CharForward = Vector3.Scale(camFlatFwd, new Vector3(1, 0, 1)).normalized;
        Vector3 m_CharRight = Vector3.Scale(flatRight, new Vector3(1, 0, 1)).normalized;

        Vector3 move;

        Vector3 direction = camFlatFwd * _verticalInput + flatRight * _horizontalInput;

        move = _verticalInput * m_CharForward * _walkSpeed + _horizontalInput * m_CharRight * _walkSpeed;

        if ((_verticalInput != 0 || _horizontalInput != 0) && !_isJumping && _isGrounded)
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), 0.05f);

        _velocity = move;

        StepClimb();
    }

    void StepClimb()
    {
        RaycastHit hitLower;
        if (Physics.Raycast(_stepRayLower.transform.position, transform.TransformDirection(-Vector3.up), out hitLower, 2f))
        {
            /*
            RaycastHit hitUpper;
            if (!Physics.Raycast(_stepRayUpper.transform.position, transform.TransformDirection(Vector3.forward), out hitUpper, 0.2f))
            {
                _rigidbody.position -= new Vector3(0f, -_stepSmooth, 0f);
            }
            */
            if(_isGrounded && (_stepRayLower.transform.position.y - hitLower.point.y <= _stepHeight))
            {
                Vector3 targetVector = new Vector3(_rigidbody.position.x, hitLower.point.y, _rigidbody.position.z);
                _rigidbody.position = Vector3.Lerp(_rigidbody.position, targetVector, Time.deltaTime / 0.1f);
                _rigidbody.velocity = new Vector3(_rigidbody.velocity.x, 0, _rigidbody.velocity.z);
            }
            else if(!_isGrounded && (_stepRayLower.transform.position.y - hitLower.point.y <= _stepHeight))
            {
                _rigidbody.position = new Vector3(_rigidbody.position.x, hitLower.point.y, _rigidbody.position.z);
                _rigidbody.velocity = new Vector3(_rigidbody.velocity.x, 0, _rigidbody.velocity.z);
            }
        }

        /*
        RaycastHit hitLower45;
        if (Physics.Raycast(_stepRayLower.transform.position, transform.TransformDirection(1.5f, 0, 1), out hitLower45, 0.1f))
        {
            RaycastHit hitUpper45;
            if (!Physics.Raycast(_stepRayUpper.transform.position, transform.TransformDirection(1.5f, 0, 1), out hitUpper45, 0.2f))
            {
                _rigidbody.position -= new Vector3(0f, -_stepSmooth, 0f);
            }
        }

        RaycastHit hitLowerMinus45;
        if (Physics.Raycast(_stepRayLower.transform.position, transform.TransformDirection(-1.5f, 0, 1), out hitLowerMinus45, 0.1f))
        {
            RaycastHit hitUpperMinus45;
            if (Physics.Raycast(_stepRayUpper.transform.position, transform.TransformDirection(-1.5f, 0, 1), out hitUpperMinus45, 0.1f))
            {
                _rigidbody.position -= new Vector3(0f, -_stepSmooth, 0f);
            }
        }
        */
    }

    void MovePlayer()
    {
        if ((_verticalInput != 0 || _horizontalInput != 0) && !_isJumping && _isGrounded)
            _rigidbody.AddForce(_velocity);
        else if (_isJumping && _isGrounded)
        {
            _rigidbody.AddForce((new Vector3(0, _jumpForce, 0)), ForceMode.Impulse);
            _isJumping = false;
        }
                    
    }

    #endregion

    #region Get Trigger Ground
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Floor") || other.CompareTag("Object"))
        {
            _isGrounded = true;
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Floor") || other.CompareTag("Object"))
        {
            _isGrounded = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Floor") || other.CompareTag("Object"))
        {
            _isGrounded = false;
        }
    }
    #endregion
}
