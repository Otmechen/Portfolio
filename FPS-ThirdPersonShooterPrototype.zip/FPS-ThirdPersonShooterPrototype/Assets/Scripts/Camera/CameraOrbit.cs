using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraOrbit : MonoBehaviour
{
    [SerializeField] Transform _followTarget;

    [SerializeField] float _maxDistance;

    [SerializeField] Vector2 _angle = new Vector2(90 * Mathf.Deg2Rad,0);

    [SerializeField] Vector2 _sensivityMouse;

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void Update()
    {
        float hor = Input.GetAxis("Mouse X");

        if(hor != 0)
        {
            _angle.x += hor * Mathf.Deg2Rad * _sensivityMouse.x;
        }

        float ver = Input.GetAxis("Mouse Y");

        if(ver != 0)
        {
            _angle.y += ver * Mathf.Deg2Rad * _sensivityMouse.y;
            _angle.y = Mathf.Clamp(_angle.y, -80 * Mathf.Deg2Rad, 80 * Mathf.Deg2Rad);
        }
    }

    private void LateUpdate()
    {
        Vector3 direction = new Vector3(
            Mathf.Cos(_angle.x) * Mathf.Cos(_angle.y),
            -Mathf.Sin(_angle.y),
            -Mathf.Sin(_angle.x) * Mathf.Cos(_angle.y));

        RaycastHit hit;
        float distance = _maxDistance;

        if(Physics.Raycast(_followTarget.position, direction, out hit, _maxDistance))
        {
            distance = (hit.point - _followTarget.position).magnitude;
        }

        transform.position = _followTarget.position + direction * distance;
        transform.rotation = Quaternion.LookRotation(_followTarget.position - transform.position);
    }

    void CalculateNearPlaneSize()
    {
        float height;
        float _width;
    }
}
