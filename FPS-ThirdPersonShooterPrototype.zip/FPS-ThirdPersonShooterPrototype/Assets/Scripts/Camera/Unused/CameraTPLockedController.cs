using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTPLockedController : MonoBehaviour
{
    [SerializeField] Camera _camera;

    [SerializeField] Vector2 _sensitivity;
    [SerializeField] Vector2 _angle;
    [SerializeField] bool _invertXAxis;
    [SerializeField] bool _invertYAxis;

    [SerializeField] Transform _lookAt;
    [SerializeField] Transform _cameraPosition;

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        GameObject camaraGO = GameObject.FindGameObjectWithTag("MainCamera");
        _camera = camaraGO.GetComponent<Camera>();

        _camera.transform.position = _cameraPosition.position;
    }

    private void FixedUpdate()
    {
        CameraTransform();
    }

    void CameraTransform()
    {
        float h = Input.GetAxis("Mouse X");
        float v = Input.GetAxis("Mouse Y");

        h = (_invertXAxis) ? (-h) : h;
        v = (_invertYAxis) ? (-v) : v;

        if (h != 0)
        {
            transform.Rotate(Vector3.up, h * 90 * _sensitivity.x * Time.deltaTime);
        }            

        if (v != 0)
        {
            _camera.transform.RotateAround(transform.position, transform.right, v * 90 * _sensitivity.y * Time.deltaTime);
        }

        _camera.transform.LookAt(_lookAt);

        Vector3 ea = _camera.transform.rotation.eulerAngles;
        _camera.transform.rotation = Quaternion.Euler(new Vector3(ea.x, ea.y, 0));
    }
}
