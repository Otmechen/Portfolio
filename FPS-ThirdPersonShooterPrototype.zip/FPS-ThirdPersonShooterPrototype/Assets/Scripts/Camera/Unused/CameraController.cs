using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    [SerializeField] Camera _camera;

    public enum CAMERA_TYPE { FREE_LOCK, LOCKED }

    public CAMERA_TYPE _type = CAMERA_TYPE.FREE_LOCK;

    [Range(0.1f, 2.5f)]
    [SerializeField] float _sensitivity;
    [SerializeField] bool _invertXAxis;
    [SerializeField] bool _invertYAxis;

    [SerializeField] Transform _lookAt;

    #region Camera Transitions
    [SerializeField] bool _inTransition;
    [SerializeField] CameraState _startState;
    [SerializeField] CameraState _endState;
    [SerializeField] float _transitionTime = 0.0f;

    [SerializeField] Transform _aimCam;

    private struct CameraState
    {
        public Vector3 _position;
        public Vector3 _rotation;
        public Transform _lookAt;
        public float _time;
    }
    #endregion

    private void Awake()
    {
        if (_type == CAMERA_TYPE.LOCKED)
            _camera.transform.parent = transform;
    }

    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    private void FixedUpdate()
    {
        if (!_inTransition)
        {
            float h = Input.GetAxis("Mouse X");
            float v = Input.GetAxis("Mouse Y");

            h = (_invertXAxis) ? (-h) : h;
            v = (_invertYAxis) ? (-v) : v;

            if (h != 0)
            {
                if (_type == CAMERA_TYPE.LOCKED) transform.Rotate(Vector3.up, h * 90 * _sensitivity * Time.deltaTime);
                else if (_type == CAMERA_TYPE.FREE_LOCK) _camera.transform.RotateAround(transform.position, transform.up, h * 90 * _sensitivity * Time.deltaTime);
            }

            if (v != 0)
            {
                _camera.transform.RotateAround(transform.position, transform.right, v * 90 * _sensitivity * Time.deltaTime);
            }

            _camera.transform.LookAt(_lookAt);

            Vector3 ea = _camera.transform.rotation.eulerAngles;
            _camera.transform.rotation = Quaternion.Euler(new Vector3(ea.x, ea.y, 0));
        }
        else
        {
            float t = (Time.time - _startState._time) / (_endState._time - _startState._time);
            _camera.transform.position = Vector3.Lerp(_startState._position, _endState._position, t);
            _camera.transform.eulerAngles = Vector3.Lerp(_startState._rotation, _endState._rotation, t);

            _camera.transform.LookAt(_endState._lookAt);
            if (t >= 1)
                _inTransition = false;
        }
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            TransitionTo(_aimCam.position, _aimCam.rotation.eulerAngles, _lookAt, 1.5f);
        }
    }

    public Camera GetCamera() { return _camera; }

    public void TransitionTo(Vector3 _finalPosition, Vector3 _finalRotation, Transform _finalLookAt, float _duration)
    {
        _startState._position = _camera.transform.position;
        _startState._rotation = _camera.transform.rotation.eulerAngles;
        _startState._lookAt = _lookAt;
        _startState._time = Time.time;

        _endState._position = _finalPosition;
        _endState._rotation = _finalRotation;
        _endState._lookAt = _finalLookAt;
        _endState._time = _startState._time + _duration;

        _transitionTime = _duration;
        _inTransition = true;
    }
}
